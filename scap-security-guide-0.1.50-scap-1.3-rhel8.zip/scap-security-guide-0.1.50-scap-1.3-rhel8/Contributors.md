<!---This file is generated using the contributors.py script. DO NOT MANUALLY EDIT!!!!
Last Modified: 2020-05-15 09:43
--->

The following people have contributed to the SCAP Security Guide project
(listed in alphabetical order):

* Frank J Cameron (CAM1244) <cameron@ctc.com>
* 0x66656c6978 <0x66656c6978@users.noreply.github.com>
* Jack Adolph <jack.adolph@gmail.com>
* Gabe Alford <redhatrises@gmail.com>
* Firas AlShafei <firas.alshafei@us.abb.com>
* Christopher Anderson <cba@fedoraproject.org>
* angystardust <angystardust@users.noreply.github.com>
* anixon-rh <55244503+anixon-rh@users.noreply.github.com>
* Chuck Atkins <chuck.atkins@kitware.com>
* Ryan Ballanger <root@rballang-admin-2.fastenal.com>
* Alex Baranowski <alex@euro-linux.com>
* Molly Jo Bault <Molly.Jo.Bault@ballardtech.com>
* Gabriel Becker <ggasparb@redhat.com>
* Alexander Bergmann <abergmann@suse.com>
* Jose Luis BG <bgjoseluis@gmail.com>
* Joseph Bisch <joseph.bisch@gmail.com>
* Jeffrey Blank <blank@eclipse.ncsc.mil>
* Olivier Bonhomme <ptitoliv@ptitoliv.net>
* Ted Brunell <tbrunell@redhat.com>
* Blake Burkhart <blake.burkhart@us.af.mil>
* Patrick Callahan <pmc@patrickcallahan.com>
* Nick Carboni <ncarboni@redhat.com>
* James Cassell <james.cassell@ll.mit.edu>
* Frank Caviggia <fcaviggi@ra.iad.redhat.com>
* Eric Christensen <echriste@redhat.com>
* Jayson Cofell <1051437+70k10@users.noreply.github.com>
* Caleb Cooper <coopercd@ornl.gov>
* Deric Crago <deric.crago@gmail.com>
* Maura Dailey <maura@eclipse.ncsc.mil>
* Klaas Demter <demter@atix.de>
* dhanushkar-wso2 <dhanushkar@wso2.com>
* Andrew DiPrinzio <andrew.diprinzio@jhuapl.edu>
* dom <dominique.blaze@devinci.fr>
* Jean-Baptiste Donnette <jean-baptiste.donnette@epita.fr>
* drax <applezip@gmail.com>
* Sebastian Dunne <sdunne@redhat.com>
* Greg Elin <gregelin@gitmachines.com>
* eradot4027 <jrtonmac@gmail.com>
* Alexis Facques <alexis.facques@mythalesgroup.io>
* Leah Fisher <lfisher047@gmail.com>
* Alijohn Ghassemlouei <alijohn.ghassemlouei@sapns2.com>
* ghylock <ghylock@gmail.com>
* Andrew Gilmore <agilmore2@gmail.com>
* Joshua Glemza <jglemza@nasa.gov>
* Nick Gompper <forestgomp@yahoo.com>
* Loren Gordon <lorengordon@users.noreply.github.com>
* Patrik Greco <sikevux@sikevux.se>
* Steve Grubb <sgrubb@redhat.com>
* Marek Haicman <mhaicman@redhat.com>
* Rebekah Hayes <rhayes@corp.rivierautilities.com>
* Trey Henefield <thenefield@gmail.com>
* Henning Henkel <henning.henkel@helvetia.ch>
* hex2a <hex2a@users.noreply.github.com>
* John Hooks <jhooks@starscream.pa.jhbcomputers.com>
* Jakub Hrozek <jhrozek@redhat.com>
* De Huo <De.Huo@windriver.com>
* Ultra IA <42849651+cyarbrough76@users.noreply.github.com>
* Robin Price II <robin@redhat.com>
* Yasir Imam <yimam@redhat.com>
* Jiri Jaburek <jjaburek@redhat.com>
* Keith Jackson <keithkjackson@gmail.com>
* Jeremiah Jahn <jeremiah@goodinassociates.com>
* Stephan Joerrens <Stephan.Joerrens@fiduciagad.de>
* Jono <jono@ubuntu-18.localdomain>
* Kai Kang <kai.kang@windriver.com>
* Charles Kernstock <charles.kernstock@ultra-ats.com>
* Yuli Khodorkovskiy <ykhodorkovskiy@tresys.com>
* Nathan Kinder <nkinder@redhat.com>
* Lee Kinser <lee.kinser@gmail.com>
* Evgeny Kolesnikov <ekolesni@redhat.com>
* Peter 'Pessoft' Kolínek <github@pessoft.com>
* Luke Kordell <luke.t.kordell@lmco.com>
* Malte Kraus <malte.kraus@suse.com>
* kspargur <kspargur@kspargur.csb>
* Amit Kumar <amitkuma@redhat.com>
* Fen Labalme <fen@civicactions.com>
* Christopher Lee <Crleekwc@gmail.com>
* Ian Lee <lee1001@llnl.gov>
* Jarrett Lee <jarrettl@umd.edu>
* Jan Lieskovsky <jlieskov@redhat.com>
* Šimon Lukašík <slukasik@redhat.com>
* Milan Lysonek <mlysonek@redhat.com>
* Fredrik Lysén <fredrik@pipemore.se>
* Caitlin Macleod <caitelatte@gmail.com>
* Matus Marhefka <mmarhefk@redhat.com>
* Jamie Lorwey Martin <jlmartin@redhat.com>
* Robert McAllister <rmcallis@redhat.com>
* Michael McConachie <michael@redhat.com>
* Khary Mendez <kharyam@gmail.com>
* Rodney Mercer <rmercer@harris.com>
* Matt Micene <nzwulfin@gmail.com>
* Brian Millett <bmillett@gmail.com>
* Mixer9 <35545791+Mixer9@users.noreply.github.com>
* mmosel <mmosel@kde.example.com>
* Zbynek Moravec <zmoravec@redhat.com>
* Kazuo Moriwaka <moriwaka@users.noreply.github.com>
* Michael Moseley <michael@eclipse.ncsc.mil>
* Joe Nall <joe@nall.com>
* Neiloy <neiloy@redhat.com>
* Axel Nennker <axel@nennker.de>
* Michele Newman <mnewman@redhat.com>
* Sean O'Keeffe <seanokeeffe797@gmail.com>
* Ilya Okomin <ilya.okomin@oracle.com>
* Kaustubh Padegaonkar <theTuxRacer@gmail.com>
* Michael Palmiotto <mpalmiotto@tresys.com>
* Max R.D. Parmer <maxp@trystero.is>
* Jan Pazdziora <jpazdziora@redhat.com>
* pcactr <paul.c.arnold4.ctr@mail.mil>
* Kenneth Peeples <kennethwpeeples@gmail.com>
* Nathan Peters <Nathaniel.Peters@ca.com>
* Frank Lin PIAT <fpiat@klabs.be>
* Stefan Pietsch <mail.ipv4v6+gh@gmail.com>
* Vojtech Polasek <vpolasek@redhat.com>
* Orion Poplawski <orion@nwra.com>
* Nick Poyant <npoyant@redhat.com>
* Martin Preisler <mpreisle@redhat.com>
* Wesley Ceraso Prudencio <wcerasop@redhat.com>
* Raphael Sanchez Prudencio <rsprudencio@redhat.com>
* T.O. Radzy Radzykewycz <radzy@windriver.com>
* Kenyon Ralph <kenyon@kenyonralph.com>
* Mike Ralph <mralph@redhat.com>
* Rick Renshaw <Richard_Renshaw@xtoenergy.com>
* Chris Reynolds <c.reynolds82@gmail.com>
* rhayes <rhayes@rivierautilities.com>
* Pat Riehecky <riehecky@fnal.gov>
* rlucente-se-jboss <rlucente@redhat.com>
* Juan Antonio Osorio Robles <jaosorior@redhat.com>
* Matt Rogers <mrogers@redhat.com>
* Jesse Roland <j.roland277@gmail.com>
* Joshua Roys <roysjosh@gmail.com>
* rrenshaw <bofh69@yahoo.com>
* Chris Ruffalo <chris.ruffalo@gmail.com>
* Ray Shaw (Cont ARL/CISD) rvshaw <rvshaw@esme.arl.army.mil>
* Willy Santos <wsantos@redhat.com>
* Gautam Satish <gautams@hpe.com>
* Watson Sato <wsato@redhat.com>
* Satoru SATOH <satoru.satoh@gmail.com>
* Alexander Scheel <ascheel@redhat.com>
* Bryan Schneiders <pschneiders@trisept.com>
* shaneboulden <shane.boulden@gmail.com>
* Spencer Shimko <sshimko@tresys.com>
* Mark Shoger <mshoger@redhat.com>
* Thomas Sjögren <konstruktoid@users.noreply.github.com>
* Francisco Slavin <fslavin@tresys.com>
* David Smith <dsmith@eclipse.ncsc.mil>
* Kevin Spargur <kspargur@redhat.com>
* Kenneth Stailey <kstailey.lists@gmail.com>
* Leland Steinke <leland.j.steinke.ctr@mail.mil>
* Justin Stephenson <jstephen@redhat.com>
* Brian Stinson <brian@bstinson.com>
* Jake Stookey <jakestookey@gmail.com>
* Jonathan Sturges <jsturges@jsturges.remote.csb>
* Philippe Thierry <phil@reseau-libre.net>
* Derek Thurston <thegrit@gmail.com>
* tianzhenjia <jiatianzhen@cmss.chinamobile.com>
* Paul Tittle <ptittle@cmf.nrl.navy.mil>
* tomas.hudik <tomas.hudik@embedit.cz>
* Jeb Trayer <jeb.d.trayer@uscg.mil>
* Matěj Týč <matyc@redhat.com>
* VadimDor <29509093+VadimDor@users.noreply.github.com>
* Shawn Wells <shawn@redhat.com>
* Daniel E. White <linuxdan@users.noreply.github.com>
* Roy Williams <roywilli@roywilli.redhat.com>
* Willumpie <willumpie@xs4all.nl>
* Rob Wilmoth <rwilmoth@redhat.com>
* Lucas Yamanishi <lucas.yamanishi@onyxpoint.com>
* Xirui Yang <xirui.yang@oracle.com>
* Kevin Zimmerman <kevin.zimmerman@kitware.com>
* Jan Černý <jcerny@redhat.com>
* Michal Šrubař <msrubar@redhat.com>
